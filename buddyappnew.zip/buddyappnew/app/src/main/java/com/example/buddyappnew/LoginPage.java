package com.example.buddyappnew;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginPage extends AppCompatActivity {

    Button btnLogin;
    EditText username, pass;
    TextView registerText;
    DatabaseHelper dbHelper;
    ImageView logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);

        btnLogin = findViewById(R.id.btnLogin);
        username = findViewById(R.id.username);
        pass = findViewById(R.id.pass);
        registerText = findViewById(R.id.registerText);
        logo = findViewById(R.id.logo);
        logo.setOnClickListener(v -> finish());

        dbHelper = new DatabaseHelper(this);

        btnLogin.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String password = pass.getText().toString().trim();
            if (user.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginPage.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.checkLogin(user, password)) {
                Toast.makeText(LoginPage.this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginPage.this, WelcomePage.class));
                finish();
            } else {
                Toast.makeText(LoginPage.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        registerText.setOnClickListener(v -> {
            startActivity(new Intent(LoginPage.this, PersonalDataPage.class));
            // finish(); // Removed to allow back navigation
        });
    }
} 