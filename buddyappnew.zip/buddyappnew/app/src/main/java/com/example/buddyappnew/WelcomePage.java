package com.example.buddyappnew;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomePage extends AppCompatActivity {

    Button btnLoginNow;
    TextView registerText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);

        btnLoginNow = findViewById(R.id.btnLoginNow);
        registerText = findViewById(R.id.registerText);

        btnLoginNow.setOnClickListener(v -> {
            startActivity(new Intent(WelcomePage.this, LoginPage.class));
            // finish(); // Removed to allow back navigation
        });

        registerText.setOnClickListener(v -> {
            startActivity(new Intent(WelcomePage.this, PersonalDataPage.class));
            // finish(); // Removed to allow back navigation
        });
    }
} 