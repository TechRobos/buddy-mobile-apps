package com.example.buddyappnew;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterPage extends AppCompatActivity {

    EditText username, email, password, confirmPassword;
    Button btnCreate;
    // TextView backIcon; // Removed, not used
    ImageView logo;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page);

        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        btnCreate = findViewById(R.id.btnCreate);
        // backIcon = findViewById(R.id.backIcon); // Removed, not used
        logo = findViewById(R.id.logo);

        dbHelper = new DatabaseHelper(this);

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameStr = username.getText().toString().trim();
                String emailStr = email.getText().toString().trim();
                String passwordStr = password.getText().toString().trim();
                String confirmPasswordStr = confirmPassword.getText().toString().trim();

                // Get extras from intent
                String nameStr = getIntent().getStringExtra("name") != null ? getIntent().getStringExtra("name") : "";
                String genderStr = getIntent().getStringExtra("gender") != null ? getIntent().getStringExtra("gender") : "";
                String dobStr = getIntent().getStringExtra("dob") != null ? getIntent().getStringExtra("dob") : "";
                String phoneStr = getIntent().getStringExtra("phone") != null ? getIntent().getStringExtra("phone") : "";

                // Validate all fields are filled
                if (usernameStr.isEmpty() || emailStr.isEmpty() || passwordStr.isEmpty() || confirmPasswordStr.isEmpty()) {
                    Toast.makeText(RegisterPage.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if passwords match
                if (!passwordStr.equals(confirmPasswordStr)) {
                    Toast.makeText(RegisterPage.this, "Password not same", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean success = dbHelper.registerUser(nameStr, genderStr, dobStr, phoneStr, usernameStr, emailStr, passwordStr);
                if (success) {
                    Toast.makeText(RegisterPage.this, "Register successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(RegisterPage.this, LoginPage.class));
                    // finish(); // Removed to allow back navigation
                } else {
                    Toast.makeText(RegisterPage.this, "Registration failed (username may already exist)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // backIcon.setOnClickListener(new View.OnClickListener() { // Removed, not used
        //     @Override
        //     public void onClick(View v) {
        //         finish();
        //     }
        // });

        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
} 