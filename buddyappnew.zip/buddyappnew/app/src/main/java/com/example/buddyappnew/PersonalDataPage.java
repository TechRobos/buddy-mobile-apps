package com.example.buddyappnew;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.util.regex.Pattern;

import androidx.appcompat.app.AppCompatActivity;

public class PersonalDataPage extends AppCompatActivity {

    EditText name, dob, phone;
    Button btnNext;
    ImageView logo;
    RadioGroup genderGroup;
    RadioButton radioMale, radioFemale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personal_data_page);

        name = findViewById(R.id.name);
        genderGroup = findViewById(R.id.genderGroup);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        dob = findViewById(R.id.dob);
        phone = findViewById(R.id.phone);
        btnNext = findViewById(R.id.btnNext);
        logo = findViewById(R.id.logo);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameStr = name.getText().toString().trim();
                String genderStr = "";
                int selectedGenderId = genderGroup.getCheckedRadioButtonId();
                if (selectedGenderId == R.id.radioMale) {
                    genderStr = "Male";
                } else if (selectedGenderId == R.id.radioFemale) {
                    genderStr = "Female";
                }
                String dobStr = dob.getText().toString().trim();
                String phoneStr = phone.getText().toString().trim();

                // Validate all fields are filled
                if (nameStr.isEmpty() || genderStr.isEmpty() || dobStr.isEmpty() || phoneStr.isEmpty()) {
                    Toast.makeText(PersonalDataPage.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Validate date of birth format dd/mm/yyyy
                Pattern dobPattern = Pattern.compile("^\\d{2}/\\d{2}/\\d{4}$");
                if (!dobPattern.matcher(dobStr).matches()) {
                    Toast.makeText(PersonalDataPage.this, "Date of Birth must be in dd/mm/yyyy format", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(PersonalDataPage.this, RegisterPage.class);
                intent.putExtra("name", nameStr);
                intent.putExtra("gender", genderStr);
                intent.putExtra("dob", dobStr);
                intent.putExtra("phone", phoneStr);
                startActivity(intent);
                // finish(); // Removed to allow back navigation
            }
        });

        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
} 